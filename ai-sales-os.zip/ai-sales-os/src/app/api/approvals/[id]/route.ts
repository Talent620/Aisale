import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAuth, parseBody, serverError } from "@/lib/api";
import { approvalDecisionSchema } from "@/lib/validations";

export const dynamic = "force-dynamic";

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const a = await getAuth();
  if ("res" in a) return a.res;

  const b = await parseBody(req, approvalDecisionSchema);
  if ("res" in b) return b.res;

  try {
    const approval = await prisma.approvalRequest.findFirst({
      where: { id: params.id, companyId: a.ctx.companyId },
    });
    if (!approval) return NextResponse.json({ error: "Not found" }, { status: 404 });
    if (approval.status !== "PENDING") {
      return NextResponse.json({ error: "Already decided" }, { status: 409 });
    }

    if (b.data.status === "REJECTED") {
      const rejected = await prisma.approvalRequest.update({
        where: { id: params.id },
        data: {
          status: "REJECTED",
          decisionNote: b.data.decisionNote,
          decidedAt: new Date(),
          decidedById: a.ctx.userId,
        },
      });
      return NextResponse.json(rejected);
    }

    // APPROVED → perform the side effects, then mark EXECUTED.
    const payload = (approval.payload ?? {}) as Record<string, unknown>;

    await prisma.$transaction(async (tx) => {
      if (approval.campaignMessageId) {
        await tx.campaignMessage.update({
          where: { id: approval.campaignMessageId },
          data: { approved: true },
        });
      }

      // Turn an approved outreach draft into a concrete follow-up task.
      if (approval.leadId) {
        const kind = typeof payload.kind === "string" ? payload.kind : "message";
        await tx.task.create({
          data: {
            companyId: a.ctx.companyId,
            leadId: approval.leadId,
            assigneeId: a.ctx.userId,
            title: `Send approved ${kind.toLowerCase()}`,
            description: typeof payload.body === "string" ? payload.body.slice(0, 1000) : undefined,
            priority: "HIGH",
            source: "AI",
            dueDate: new Date(Date.now() + 2 * 86_400_000),
          },
        });
        await tx.leadActivity.create({
          data: {
            companyId: a.ctx.companyId,
            leadId: approval.leadId,
            userId: a.ctx.userId,
            type: "MESSAGE_SENT",
            title: "AI draft approved",
            body: approval.title,
          },
        });
      }

      await tx.approvalRequest.update({
        where: { id: params.id },
        data: {
          status: "EXECUTED",
          decisionNote: b.data.decisionNote,
          decidedAt: new Date(),
          decidedById: a.ctx.userId,
        },
      });
    });

    const fresh = await prisma.approvalRequest.findUnique({ where: { id: params.id } });
    return NextResponse.json(fresh);
  } catch (err) {
    return serverError(err, "approval.PATCH");
  }
}
